ABORTED = 'Aborted'
FAILED = 'Failed'
NOT_PROCESSED = 'NotProcessed'
COMPLETED = 'Completed'

ERROR_STATES = (
    ABORTED,
    FAILED,
    NOT_PROCESSED,
)
